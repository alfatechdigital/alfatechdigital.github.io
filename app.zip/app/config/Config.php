<?php
// Application Configuration
define('APP_NAME', 'Learning Management System');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/app');
define('APP_PATH', __DIR__ . '/../');

// Database Configuration
define('DB_PATH', __DIR__ . '/../../data/app.db');

// Session Configuration
define('SESSION_TIMEOUT', 3600); // 1 hour

// Upload Configuration
define('UPLOAD_PATH', APP_PATH . 'public/uploads/');
define('UPLOAD_MAX_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'jpg', 'jpeg', 'png', 'gif']);

// Email Configuration (optional)
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'your-email@gmail.com');
define('MAIL_PASSWORD', 'your-password');
define('MAIL_FROM', 'noreply@lms.local');

// Pagination
define('ITEMS_PER_PAGE', 10);

// Default Admin Credentials
define('DEFAULT_ADMIN_USERNAME', 'admin');
define('DEFAULT_ADMIN_PASSWORD', 'admin123');
define('DEFAULT_ADMIN_EMAIL', 'admin@example.com');

// Assessment Limits
define('DIAGNOSTIC_ASSESSMENT_LIMIT', 1); // User can take only once
define('QUIZ_ATTEMPT_LIMIT', 3); // User can attempt quiz max 3 times
?>
