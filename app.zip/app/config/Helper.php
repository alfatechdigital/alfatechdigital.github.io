<?php
session_start();

// User authentication helper functions
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function isUser() {
    return isLoggedIn() && $_SESSION['role'] === 'user';
}

function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

function getCurrentUserRole() {
    return $_SESSION['role'] ?? null;
}

function getCurrentUsername() {
    return $_SESSION['username'] ?? null;
}

function login($userId, $username, $role, $classId = null) {
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    $_SESSION['class_id'] = $classId;
    $_SESSION['login_time'] = time();
}

function logout() {
    session_destroy();
    header('Location: ' . APP_URL . '/index.php?page=login');
    exit();
}

function redirect($url) {
    header('Location: ' . $url);
    exit();
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        redirect(APP_URL . '/index.php?page=login');
    }
}

function redirectIfNotAdmin() {
    if (!isAdmin()) {
        redirect(APP_URL . '/index.php?page=unauthorized');
    }
}

// Hash password
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Verify password
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Sanitize input
function sanitize($input) {
    return htmlspecialchars(stripslashes(trim($input)));
}

// Validate email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Flash message functions
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function displayFlash() {
    $flash = getFlash();
    if ($flash) {
        $alertClass = ($flash['type'] === 'error') ? 'bg-red-100 border-l-4 border-red-500 text-red-700' : 'bg-green-100 border-l-4 border-green-500 text-green-700';
        echo '<div class="' . $alertClass . ' p-4 mb-4" role="alert">';
        echo '<p>' . htmlspecialchars($flash['message']) . '</p>';
        echo '</div>';
    }
}

// Format date
function formatDate($date, $format = 'd/m/Y H:i') {
    return date($format, strtotime($date));
}

// Convert array to JSON safely
function toJSON($data) {
    return json_encode($data);
}

// Convert JSON to array safely
function fromJSON($json) {
    return json_decode($json, true);
}

// Pagination function
function getPaginationData($totalItems, $currentPage = 1, $itemsPerPage = ITEMS_PER_PAGE) {
    $totalPages = ceil($totalItems / $itemsPerPage);
    $offset = ($currentPage - 1) * $itemsPerPage;
    
    return [
        'totalItems' => $totalItems,
        'totalPages' => $totalPages,
        'currentPage' => $currentPage,
        'offset' => $offset,
        'limit' => $itemsPerPage
    ];
}

// Check if file upload is valid
function isValidUpload($file) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    if ($file['size'] > UPLOAD_MAX_SIZE) {
        return false;
    }
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    // Allowed MIME types
    $allowed = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'image/jpeg',
        'image/png',
        'image/gif'
    ];
    
    return in_array($mime, $allowed);
}

// Save uploaded file
function saveUploadedFile($file) {
    if (!isValidUpload($file)) {
        return false;
    }
    
    $filename = uniqid() . '_' . basename($file['name']);
    $filepath = UPLOAD_PATH . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }
    
    return false;
}

// CSRF Token Generation
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

?>
