<?php
class Database {
    private $db;
    private $db_path;

    public function __construct() {
        $this->db_path = __DIR__ . '/../../data/app.db';
        $this->connect();
        $this->initializeDatabase();
    }

    public function connect() {
        try {
            $this->db = new PDO('sqlite:' . $this->db_path);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die('Database connection error: ' . $e->getMessage());
        }
    }

    private function initializeDatabase() {
        // Check if database is already initialized
        $tables = $this->db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll();
        if (count($tables) > 0) {
            return;
        }

        // Create tables
        $sql = file_get_contents(__DIR__ . '/schema.sql');
        $this->db->exec($sql);
    }

    public function prepare($sql) {
        return $this->db->prepare($sql);
    }

    public function query($sql) {
        return $this->db->query($sql);
    }

    public function execute($stmt) {
        return $stmt->execute();
    }

    public function lastInsertId() {
        return $this->db->lastInsertId();
    }

    public function beginTransaction() {
        $this->db->beginTransaction();
    }

    public function commit() {
        $this->db->commit();
    }

    public function rollback() {
        $this->db->rollback();
    }

    public function close() {
        $this->db = null;
    }

    public function getConnection() {
        return $this->db;
    }
}
?>
