<?php
require_once __DIR__ . '/../config/Database.php';

class Material {
    private $db;
    private $table = 'materials';

    public function __construct() {
        $this->db = new Database();
    }

    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getByClassAndType($classId, $type = null) {
        $sql = "SELECT * FROM {$this->table} WHERE class_id = ? AND is_published = 1";
        
        if ($type) {
            $sql .= " AND type = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$classId, $type]);
        } else {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$classId]);
        }
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByClass($classId) {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE class_id = ? ORDER BY created_at DESC");
        $stmt->execute([$classId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllMaterials($page = 1, $limit = ITEMS_PER_PAGE) {
        $offset = ($page - 1) * $limit;
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} ORDER BY created_at DESC LIMIT ? OFFSET ?"
        );
        $stmt->execute([$limit, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $stmt = $this->db->prepare(
            "INSERT INTO {$this->table} (name, description, type, content, file_url, class_id, is_published, created_by) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        
        return $stmt->execute([
            $data['name'],
            $data['description'] ?? null,
            $data['type'],
            $data['content'],
            $data['file_url'] ?? null,
            $data['class_id'],
            $data['is_published'] ?? 0,
            $data['created_by']
        ]);
    }

    public function update($id, $data) {
        $fields = ['updated_at = CURRENT_TIMESTAMP'];
        $values = [];

        $allowedFields = ['name', 'description', 'content', 'file_url', 'is_published', 'type'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $fields[] = "$field = ?";
                $values[] = $data[$field];
            }
        }

        $values[] = $id;
        $sql = "UPDATE {$this->table} SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }

    public function delete($id) {
        // Delete associated quiz questions
        $stmt = $this->db->prepare("DELETE FROM quiz_questions WHERE quiz_id = ?");
        $stmt->execute([$id]);
        
        // Delete the material
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function count() {
        $stmt = $this->db->query("SELECT COUNT(*) as count FROM {$this->table}");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }

    public function countByType($type) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM {$this->table} WHERE type = ?");
        $stmt->execute([$type]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }

    public function countByClass($classId) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM {$this->table} WHERE class_id = ?");
        $stmt->execute([$classId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }

    public function getTypes() {
        return ['slide', 'modul', 'lkpd', 'kuis'];
    }

    public function setMaterialAccess($materialId, $classIds) {
        // Remove existing access
        $stmt = $this->db->prepare("DELETE FROM material_access WHERE material_id = ?");
        $stmt->execute([$materialId]);

        // Add new access
        foreach ($classIds as $classId) {
            $stmt = $this->db->prepare(
                "INSERT INTO material_access (material_id, class_id, is_available) VALUES (?, ?, 1)"
            );
            $stmt->execute([$materialId, $classId]);
        }
    }

    public function getMaterialAccess($materialId) {
        $stmt = $this->db->prepare(
            "SELECT class_id FROM material_access WHERE material_id = ? AND is_available = 1"
        );
        $stmt->execute([$materialId]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map(fn($r) => $r['class_id'], $results);
    }
}
?>
