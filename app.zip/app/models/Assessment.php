<?php
require_once __DIR__ . '/../config/Database.php';

class Assessment {
    private $db;
    private $table = 'diagnostic_assessment';

    public function __construct() {
        $this->db = new Database();
    }

    public function saveDiagnosticAssessment($userId, $answers, $score) {
        $stmt = $this->db->prepare(
            "INSERT INTO {$this->table} (user_id, answers, score) VALUES (?, ?, ?)"
        );
        
        return $stmt->execute([
            $userId,
            json_encode($answers),
            $score
        ]);
    }

    public function getDiagnosticAssessment($userId) {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getDiagnosticQuestions() {
        // These are predefined questions for diagnostic assessment
        return [
            [
                'id' => 1,
                'question' => 'Apa yang Anda ketahui tentang topik ini?',
                'type' => 'essay'
            ],
            [
                'id' => 2,
                'question' => 'Sebutkan 3 konsep penting dalam pelajaran ini',
                'type' => 'essay'
            ],
            [
                'id' => 3,
                'question' => 'Apa yang ingin Anda pelajari dari topik ini?',
                'type' => 'essay'
            ],
            [
                'id' => 4,
                'question' => 'Bagaimana gaya belajar Anda? (Visual/Auditori/Kinestetik)',
                'type' => 'choice',
                'options' => ['Visual', 'Auditori', 'Kinestetik']
            ]
        ];
    }

    public function getAllAssessments($page = 1, $limit = ITEMS_PER_PAGE) {
        $offset = ($page - 1) * $limit;
        $stmt = $this->db->prepare(
            "SELECT da.*, u.username, u.full_name FROM {$this->table} da 
             JOIN users u ON da.user_id = u.id 
             ORDER BY da.completed_at DESC LIMIT ? OFFSET ?"
        );
        $stmt->execute([$limit, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function count() {
        $stmt = $this->db->query("SELECT COUNT(*) as count FROM {$this->table}");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }
}
?>
