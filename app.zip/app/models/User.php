<?php
require_once __DIR__ . '/../config/Database.php';

class User {
    private $db;
    private $table = 'users';

    public function __construct() {
        $this->db = new Database();
    }

    public function findByUsername($username) {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE username = ?");
        $stmt->execute([$username]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function findByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $stmt = $this->db->prepare(
            "INSERT INTO {$this->table} (username, email, password, full_name, role, class_id, is_active) 
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        
        return $stmt->execute([
            $data['username'],
            $data['email'],
            hashPassword($data['password']),
            $data['full_name'],
            $data['role'] ?? 'user',
            $data['class_id'] ?? null,
            1
        ]);
    }

    public function update($id, $data) {
        $fields = [];
        $values = [];

        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $fields[] = "$key = ?";
                $values[] = $value;
            }
        }

        $values[] = $id;
        $sql = "UPDATE {$this->table} SET " . implode(', ', $fields) . ", updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getAllUsers($role = null) {
        $sql = "SELECT * FROM {$this->table}";
        if ($role) {
            $sql .= " WHERE role = ?";
        }
        $sql .= " ORDER BY created_at DESC";
        
        if ($role) {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$role]);
        } else {
            $stmt = $this->db->query($sql);
        }
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function markDiagnosticComplete($userId) {
        $stmt = $this->db->prepare("UPDATE {$this->table} SET diagnostic_completed = 1 WHERE id = ?");
        return $stmt->execute([$userId]);
    }

    public function isDiagnosticCompleted($userId) {
        $stmt = $this->db->prepare("SELECT diagnostic_completed FROM {$this->table} WHERE id = ?");
        $stmt->execute([$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['diagnostic_completed'] == 1;
    }

    public function authenticate($username, $password) {
        $user = $this->findByUsername($username);
        
        if ($user && verifyPassword($password, $user['password'])) {
            return $user;
        }
        
        return false;
    }

    public function countByRole($role = null) {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        if ($role) {
            $stmt = $this->db->prepare($sql . " WHERE role = ?");
            $stmt->execute([$role]);
        } else {
            $stmt = $this->db->query($sql);
        }
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }
}
?>
