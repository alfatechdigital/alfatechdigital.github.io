<?php
require_once __DIR__ . '/../config/Database.php';

class Quiz {
    private $db;
    private $table = 'quiz_questions';

    public function __construct() {
        $this->db = new Database();
    }

    public function addQuestion($data) {
        $stmt = $this->db->prepare(
            "INSERT INTO {$this->table} (quiz_id, question_text, question_type, options, correct_answer, order_num) 
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        
        return $stmt->execute([
            $data['quiz_id'],
            $data['question_text'],
            $data['question_type'],
            $data['options'] ?? null,
            $data['correct_answer'] ?? null,
            $data['order_num'] ?? 0
        ]);
    }

    public function getQuestions($quizId) {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE quiz_id = ? ORDER BY order_num ASC"
        );
        $stmt->execute([$quizId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateQuestion($questionId, $data) {
        $fields = [];
        $values = [];

        $allowedFields = ['question_text', 'question_type', 'options', 'correct_answer', 'order_num'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $fields[] = "$field = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($fields)) {
            return false;
        }

        $values[] = $questionId;
        $sql = "UPDATE {$this->table} SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }

    public function deleteQuestion($questionId) {
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE id = ?");
        return $stmt->execute([$questionId]);
    }

    public function getAttempts($userId, $materialId) {
        $stmt = $this->db->prepare(
            "SELECT * FROM user_assessment_attempts WHERE user_id = ? AND material_id = ? ORDER BY completed_at DESC"
        );
        $stmt->execute([$userId, $materialId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function saveAttempt($data) {
        // Get current attempt number
        $stmt = $this->db->prepare(
            "SELECT MAX(attempt_number) as max_attempt FROM user_assessment_attempts WHERE user_id = ? AND material_id = ?"
        );
        $stmt->execute([$data['user_id'], $data['material_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $attemptNumber = ($result['max_attempt'] ?? 0) + 1;

        $stmt = $this->db->prepare(
            "INSERT INTO user_assessment_attempts (user_id, material_id, answers, score, attempt_number) 
             VALUES (?, ?, ?, ?, ?)"
        );
        
        return $stmt->execute([
            $data['user_id'],
            $data['material_id'],
            json_encode($data['answers']),
            $data['score'] ?? 0,
            $attemptNumber
        ]);
    }

    public function canAttemptQuiz($userId, $materialId) {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) as count FROM user_assessment_attempts WHERE user_id = ? AND material_id = ?"
        );
        $stmt->execute([$userId, $materialId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] < QUIZ_ATTEMPT_LIMIT;
    }

    public function getAttemptsCount($userId, $materialId) {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) as count FROM user_assessment_attempts WHERE user_id = ? AND material_id = ?"
        );
        $stmt->execute([$userId, $materialId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }

    public function getBestScore($userId, $materialId) {
        $stmt = $this->db->prepare(
            "SELECT MAX(score) as best_score FROM user_assessment_attempts WHERE user_id = ? AND material_id = ?"
        );
        $stmt->execute([$userId, $materialId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['best_score'] ?? 0;
    }
}
?>
