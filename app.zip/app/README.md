# Learning Management System (LMS)

Aplikasi web dinamis berbasis PHP dan SQLite untuk mengelola pembelajaran digital.

## 📋 Fitur Utama

### 1. **Autentikasi & Login**
- Login user dan admin
- Sistem registrasi self-service
- Session management
- Password encryption

### 2. **Asesmen Diagnostik**
- Wajib diisi saat login pertama (1x saja)
- Pertanyaan essay dan pilihan ganda
- Penyimpanan jawaban user

### 3. **Manajemen Admin**

#### 📚 Manajemen Kelas
- CRUD kelas (Tambah, Edit, Hapus)
- Deskripsi kelas
- Pengorganisasian siswa per kelas

#### 📖 Manajemen Materi
- 4 Tipe materi: Slide, Modul Ajar, LKPD, Kuis
- Upload file (PDF, DOC, PPT, IMG)
- Publikasi/Draft
- Pengaturan akses per kelas

#### 👥 Manajemen User
- Tambah user manual
- Edit profil user
- Pengaturan role (User/Admin)
- Penugasan user ke kelas

#### 📊 Manajemen Asesmen
- Laporan asesmen diagnostik
- Tracking skor siswa
- Riwayat percobaan kuis

### 4. **Fitur User/Siswa**
- Dashboard pembelajaran personal
- Akses materi berdasarkan kelas
- Slide materi interaktif
- Modul ajar
- LKPD (Lembar Kerja Peserta Didik)
- Kuis dengan 3x percobaan maksimal
- Tracking skor dan progress

## 🛠️ Instalasi

### Persyaratan
- PHP 7.4+
- SQLite3
- Web Server (Apache, Nginx, atau built-in PHP server)
- Browser modern

### Langkah-langkah

1. **Clone/Download Project**
```bash
cd g:\My Drive\alfatechdigital.github.io\app
```

2. **Buat folder data**
```bash
mkdir data
chmod 755 data
```

3. **Jalankan dengan PHP Built-in Server**
```bash
php -S localhost:8000
```

4. **Akses aplikasi**
- Buka browser: `http://localhost:8000`

### Kredensial Default

**Admin:**
- Username: `admin`
- Password: `admin123`

**User Demo:**
- Username: `user`
- Password: `user123`

## 📁 Struktur Folder

```
app/
├── config/
│   ├── Config.php          # Konfigurasi aplikasi
│   ├── Database.php        # Koneksi database
│   ├── Helper.php          # Fungsi helper
│   └── schema.sql          # Skema database
├── controllers/
│   ├── AuthController.php  # Kontrol autentikasi
│   ├── AdminController.php # Kontrol admin
│   └── UserController.php  # Kontrol user
├── models/
│   ├── User.php
│   ├── ClassModel.php
│   ├── Material.php
│   ├── Quiz.php
│   └── Assessment.php
├── views/
│   ├── auth/
│   │   ├── login.php
│   │   ├── register.php
│   │   └── diagnostic.php
│   ├── admin/
│   │   ├── dashboard.php
│   │   ├── kelas.php
│   │   ├── kelas_form.php
│   │   ├── materi.php
│   │   ├── materi_form.php
│   │   ├── user.php
│   │   ├── user_form.php
│   │   └── assessment.php
│   └── user/
│       ├── dashboard.php
│       ├── material_detail.php
│       └── quiz.php
├── public/
│   ├── css/
│   ├── js/
│   └── uploads/            # Tempat upload file materi
├── data/
│   └── app.db              # Database SQLite (auto-generate)
└── index.php               # Entry point aplikasi
```

## 🔑 Alur Penggunaan

### Untuk Admin

1. Login dengan username `admin`
2. Ke Dashboard Admin
3. Kelola Kelas → Tambah kelas baru
4. Kelola Materi → Tambah slide, modul, LKPD, kuis per kelas
5. Kelola User → Tambah user dan assign ke kelas
6. Lihat Laporan Asesmen

### Untuk User/Siswa

1. Register akun atau login dengan user demo
2. Isi Asesmen Diagnostik (wajib, 1x saja)
3. Akses Dashboard Pembelajaran
4. Belajar materi: slide, modul, LKPD
5. Isi Kuis (max 3x percobaan)
6. Lihat riwayat skor

## 💾 Database Schema

### Tabel Utama

**users**
- ID, username, email, password, full_name, role (user/admin)
- class_id, is_active, diagnostic_completed

**classes**
- ID, name, description, created_by, created_at

**materials**
- ID, name, description, type (slide/modul/lkpd/kuis)
- content, file_url, class_id, is_published

**quiz_questions**
- ID, quiz_id, question_text, question_type, options, correct_answer

**diagnostic_assessment**
- ID, user_id, answers (JSON), score

**user_assessment_attempts**
- ID, user_id, material_id, answers (JSON), score, attempt_number

## 🔒 Keamanan

- Password di-hash menggunakan bcrypt
- Input validation dan sanitization
- CSRF prevention ready
- SQL injection protection (prepared statements)
- Session management

## 📝 Fitur Tambahan yang Bisa Dikembangkan

1. **Export/Import**
   - Export laporan asesmen ke Excel/PDF
   - Import user dari CSV

2. **Analytics**
   - Grafik progress siswa
   - Heatmap kinerja per kelas

3. **Notifikasi**
   - Email notifikasi saat ada materi baru
   - Reminder kuis

4. **Gamification**
   - Poin dan badge
   - Leaderboard

5. **Live Chat**
   - Forum diskusi
   - Chat real-time

## 🐛 Troubleshooting

### Database tidak membuat table
- Periksa folder `data/` ada permission write
- Pastikan SQLite extension enabled di PHP

### Upload file gagal
- Pastikan folder `public/uploads/` exist dan writable
- Periksa file size tidak melebihi 5MB
- Format file sesuai (pdf, doc, ppt, jpg, png)

### Login gagal
- Pastikan database sudah terbuat
- Cek username/password
- Clear browser cache

## 📞 Support

Untuk pertanyaan atau bug report, hubungi developer.

## 📄 Lisensi

MIT License - Bebas digunakan untuk keperluan pribadi dan komersial.

---

**Selamat menggunakan LMS!** 🎓
