<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Learning Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .glass {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 min-h-screen flex items-center justify-center p-4">
    <div class="glass p-8 rounded-2xl shadow-2xl w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">LMS</h1>
            <p class="text-gray-600">Learning Management System</p>
        </div>

        <?php displayFlash(); ?>

        <form method="POST" action="<?php echo APP_URL; ?>/index.php?action=login" class="space-y-4">
            <div>
                <label class="block text-gray-700 font-semibold mb-2">Username</label>
                <input type="text" name="username" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-2">Password</label>
                <input type="password" name="password" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition">
                Login
            </button>
        </form>

        <div class="mt-6 text-center">
            <p class="text-gray-600">Belum punya akun? <a href="<?php echo APP_URL; ?>/index.php?page=register" class="text-blue-600 font-semibold hover:underline">Daftar di sini</a></p>
        </div>

        <!-- Demo Credentials -->
        <div class="mt-6 p-4 bg-yellow-100 border border-yellow-400 rounded-lg">
            <p class="text-sm text-gray-700"><strong>Demo User:</strong></p>
            <p class="text-sm text-gray-600">Username: user | Password: user123</p>
            <p class="text-sm text-gray-700 mt-2"><strong>Demo Admin:</strong></p>
            <p class="text-sm text-gray-600">Username: admin | Password: admin123</p>
        </div>
    </div>
</body>
</html>
