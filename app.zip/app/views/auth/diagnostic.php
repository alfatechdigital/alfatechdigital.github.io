<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asesmen Diagnostik</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="bg-white rounded-lg shadow-lg p-8 max-w-2xl w-full">
            <h1 class="text-3xl font-bold text-center mb-2 text-gray-800">Asesmen Diagnostik</h1>
            <p class="text-center text-gray-600 mb-8">Silakan isi asesmen ini untuk memahami kebutuhan pembelajaran Anda. Ini hanya perlu dilakukan sekali.</p>

            <?php displayFlash(); ?>

            <form method="POST" action="<?php echo APP_URL; ?>/index.php?action=save_diagnostic" class="space-y-8">
                <?php
                $assessmentModel = new \Assessment();
                $questions = $assessmentModel->getDiagnosticQuestions();
                
                foreach ($questions as $question):
                ?>
                    <div class="border-l-4 border-blue-500 pl-4 py-2">
                        <label class="block text-gray-800 font-semibold mb-3">
                            <?php echo htmlspecialchars($question['question']); ?>
                        </label>
                        
                        <?php if ($question['type'] === 'essay'): ?>
                            <textarea name="answer_<?php echo $question['id']; ?>" required 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                rows="4" placeholder="Jawaban Anda..."></textarea>
                        <?php elseif ($question['type'] === 'choice'): ?>
                            <div class="space-y-2">
                                <?php foreach ($question['options'] as $option): ?>
                                    <label class="flex items-center">
                                        <input type="radio" name="answer_<?php echo $question['id']; ?>" value="<?php echo htmlspecialchars($option); ?>" required class="mr-3">
                                        <span class="text-gray-700"><?php echo htmlspecialchars($option); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <div class="text-center">
                    <button type="submit" class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                        Simpan Asesmen
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
