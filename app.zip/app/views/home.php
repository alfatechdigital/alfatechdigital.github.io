<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - LMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 min-h-screen">
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="text-2xl font-bold text-blue-600">LMS</div>
                <div class="space-x-4">
                    <a href="<?php echo APP_URL; ?>/index.php?page=login" class="text-gray-700 hover:text-blue-600">Login</a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=register" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Daftar</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="min-h-[calc(100vh-64px)] flex items-center justify-center p-4">
        <div class="text-center text-white">
            <h1 class="text-5xl font-bold mb-4">Learning Management System</h1>
            <p class="text-xl mb-8">Platform Pembelajaran Digital untuk Guru dan Siswa</p>
            <div class="space-x-4">
                <a href="<?php echo APP_URL; ?>/index.php?page=login" class="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 inline-block">Login Sekarang</a>
                <a href="<?php echo APP_URL; ?>/index.php?page=register" class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 inline-block border-2 border-white">Daftar</a>
            </div>

            <div class="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl">
                <div class="bg-white bg-opacity-90 p-6 rounded-lg">
                    <div class="text-3xl mb-2">📚</div>
                    <h3 class="text-xl font-bold text-gray-800">Materi Pembelajaran</h3>
                    <p class="text-gray-600">Akses slide, modul, LKPD dan kuis</p>
                </div>
                <div class="bg-white bg-opacity-90 p-6 rounded-lg">
                    <div class="text-3xl mb-2">📊</div>
                    <h3 class="text-xl font-bold text-gray-800">Asesmen Interaktif</h3>
                    <p class="text-gray-600">Kuis dan asesmen terintegrasi</p>
                </div>
                <div class="bg-white bg-opacity-90 p-6 rounded-lg">
                    <div class="text-3xl mb-2">👨‍🏫</div>
                    <h3 class="text-xl font-bold text-gray-800">Manajemen Konten</h3>
                    <p class="text-gray-600">Kelola materi dan siswa dengan mudah</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
