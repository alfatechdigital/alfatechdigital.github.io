<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Tidak Ditemukan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="text-center">
            <h1 class="text-6xl font-bold text-orange-600 mb-4">🔍 404</h1>
            <h2 class="text-3xl font-bold text-gray-800 mb-2">Halaman Tidak Ditemukan</h2>
            <p class="text-gray-600 mb-8">Halaman yang Anda cari tidak ada atau telah dipindahkan.</p>
            <a href="<?php echo APP_URL; ?>/index.php" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 inline-block">
                Kembali ke Halaman Utama
            </a>
        </div>
    </div>
</body>
</html>
