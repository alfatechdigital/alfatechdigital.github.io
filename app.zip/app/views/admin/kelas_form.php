<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Kelas</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-blue-600">LMS Admin</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-700">Selamat datang, <strong><?php echo getCurrentUsername(); ?></strong></span>
                    <a href="<?php echo APP_URL; ?>/index.php?action=logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4">
                <h2 class="text-lg font-bold text-gray-800 mb-4">Menu Admin</h2>
                <nav class="space-y-2">
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_dashboard" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_kelas" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded bg-blue-100">
                        <i class="fas fa-graduation-cap mr-2"></i>Manajemen Kelas
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_materi" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-book mr-2"></i>Manajemen Materi
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_user" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-users mr-2"></i>Manajemen User
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_assessment" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-clipboard mr-2"></i>Asesmen
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-8">
            <?php displayFlash(); ?>

            <h2 class="text-2xl font-bold text-gray-800 mb-6">
                <?php 
                $id = $_GET['id'] ?? null;
                $class = null;
                if ($id) {
                    $classModel = new \ClassModel();
                    $class = $classModel->findById($id);
                    echo 'Edit Kelas';
                } else {
                    echo 'Tambah Kelas Baru';
                }
                ?>
            </h2>

            <div class="bg-white p-6 rounded-lg shadow max-w-2xl">
                <form method="POST" action="<?php echo APP_URL; ?>/index.php?action=<?php echo $class ? 'update_class' : 'add_class'; ?>">
                    <?php if ($class): ?>
                        <input type="hidden" name="id" value="<?php echo $class['id']; ?>">
                    <?php endif; ?>

                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold mb-2">Nama Kelas <span class="text-red-600">*</span></label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($class['name'] ?? ''); ?>" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold mb-2">Deskripsi</label>
                        <textarea name="description" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" rows="4"><?php echo htmlspecialchars($class['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="flex gap-4">
                        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                            <?php echo $class ? 'Update Kelas' : 'Tambah Kelas'; ?>
                        </button>
                        <a href="<?php echo APP_URL; ?>/index.php?page=admin_kelas" class="bg-gray-400 text-white px-6 py-2 rounded-lg hover:bg-gray-500">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
