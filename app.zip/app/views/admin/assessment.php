<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Asesmen</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-blue-600">LMS Admin</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-700">Selamat datang, <strong><?php echo getCurrentUsername(); ?></strong></span>
                    <a href="<?php echo APP_URL; ?>/index.php?action=logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4">
                <h2 class="text-lg font-bold text-gray-800 mb-4">Menu Admin</h2>
                <nav class="space-y-2">
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_dashboard" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_kelas" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-graduation-cap mr-2"></i>Manajemen Kelas
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_materi" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-book mr-2"></i>Manajemen Materi
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_user" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-users mr-2"></i>Manajemen User
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_assessment" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded bg-blue-100">
                        <i class="fas fa-clipboard mr-2"></i>Asesmen
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-8">
            <?php displayFlash(); ?>

            <h2 class="text-2xl font-bold text-gray-800 mb-4">📊 Laporan Asesmen Diagnostik</h2>

            <div class="bg-white rounded-lg shadow overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-6 py-3 text-left">No</th>
                            <th class="px-6 py-3 text-left">Username</th>
                            <th class="px-6 py-3 text-left">Nama Lengkap</th>
                            <th class="px-6 py-3 text-left">Skor</th>
                            <th class="px-6 py-3 text-left">Tanggal Selesai</th>
                            <th class="px-6 py-3 text-left">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $assessmentModel = new \Assessment();
                        $assessments = $assessmentModel->getAllAssessments();
                        $no = 1;
                        foreach ($assessments as $assessment):
                        ?>
                            <tr class="border-b hover:bg-gray-50">
                                <td class="px-6 py-3"><?php echo $no++; ?></td>
                                <td class="px-6 py-3 font-semibold"><?php echo htmlspecialchars($assessment['username']); ?></td>
                                <td class="px-6 py-3"><?php echo htmlspecialchars($assessment['full_name']); ?></td>
                                <td class="px-6 py-3">
                                    <span class="px-3 py-1 rounded-full text-sm font-semibold bg-blue-100 text-blue-800">
                                        <?php echo round($assessment['score'] ?? 0, 2); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-3"><?php echo formatDate($assessment['completed_at']); ?></td>
                                <td class="px-6 py-3">
                                    <a href="<?php echo APP_URL; ?>/index.php?page=assessment_detail&id=<?php echo $assessment['id']; ?>" class="text-blue-600 hover:underline">Lihat Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
