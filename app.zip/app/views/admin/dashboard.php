<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-blue-600">LMS Admin</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-700">Selamat datang, <strong><?php echo getCurrentUsername(); ?></strong></span>
                    <a href="<?php echo APP_URL; ?>/index.php?action=logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4">
                <h2 class="text-lg font-bold text-gray-800 mb-4">Menu Admin</h2>
                <nav class="space-y-2">
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_dashboard" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_kelas" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-graduation-cap mr-2"></i>Manajemen Kelas
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_materi" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-book mr-2"></i>Manajemen Materi
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_user" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-users mr-2"></i>Manajemen User
                    </a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_assessment" class="block px-4 py-2 text-gray-700 hover:bg-blue-100 rounded">
                        <i class="fas fa-clipboard mr-2"></i>Asesmen
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-8">
            <?php displayFlash(); ?>

            <h2 class="text-3xl font-bold text-gray-800 mb-8">Dashboard Admin</h2>

            <!-- Statistics Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <?php
                $userModel = new \User();
                $classModel = new \ClassModel();
                $materialModel = new \Material();
                ?>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Total User</p>
                            <p class="text-3xl font-bold text-blue-600"><?php echo $userModel->countByRole('user'); ?></p>
                        </div>
                        <i class="fas fa-users text-blue-400 text-4xl"></i>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Total Kelas</p>
                            <p class="text-3xl font-bold text-green-600"><?php echo $classModel->count(); ?></p>
                        </div>
                        <i class="fas fa-graduation-cap text-green-400 text-4xl"></i>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Total Materi</p>
                            <p class="text-3xl font-bold text-purple-600"><?php echo $materialModel->count(); ?></p>
                        </div>
                        <i class="fas fa-book text-purple-400 text-4xl"></i>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Total Admin</p>
                            <p class="text-3xl font-bold text-red-600"><?php echo $userModel->countByRole('admin'); ?></p>
                        </div>
                        <i class="fas fa-user-shield text-red-400 text-4xl"></i>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-xl font-bold text-gray-800 mb-4">Quick Actions</h3>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_kelas&action=add" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 text-center">+ Tambah Kelas</a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_materi&action=add" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 text-center">+ Tambah Materi</a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_user&action=add" class="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 text-center">+ Tambah User</a>
                    <a href="<?php echo APP_URL; ?>/index.php?page=admin_kelas" class="bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 text-center">Kelola Akses</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
