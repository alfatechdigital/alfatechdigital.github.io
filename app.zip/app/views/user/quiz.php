<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuis Interaktif</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <h1 class="text-2xl font-bold text-blue-600">LMS</h1>
                <div class="flex items-center space-x-4">
                    <a href="<?php echo APP_URL; ?>/index.php?page=dashboard" class="text-gray-700 hover:text-blue-600">Dashboard</a>
                    <a href="<?php echo APP_URL; ?>/index.php?action=logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-2xl mx-auto p-8">
        <?php
        if (!isLoggedIn() || !isUser()) {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"><p>Anda harus login untuk mengerjakan kuis.</p></div>';
            exit;
        }

        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"><p>Kuis tidak ditemukan.</p></div>';
            exit;
        }

        $materialModel = new \Material();
        $quizModel = new \Quiz();
        $material = $materialModel->findById($id);

        if (!$material || $material['type'] !== 'kuis') {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"><p>Kuis tidak ditemukan.</p></div>';
            exit;
        }

        $userId = getCurrentUserId();
        if (!$quizModel->canAttemptQuiz($userId, $id)) {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"><p>Anda sudah mencapai batas maksimal percobaan.</p></div>';
            exit;
        }

        $questions = $quizModel->getQuestions($id);
        ?>

        <div class="bg-white p-8 rounded-lg shadow">
            <h1 class="text-3xl font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($material['name']); ?></h1>
            <p class="text-gray-600 mb-6">Jumlah soal: <?php echo count($questions); ?></p>

            <form method="POST" action="<?php echo APP_URL; ?>/index.php?action=submit_quiz" id="quizForm">
                <input type="hidden" name="material_id" value="<?php echo $id; ?>">

                <?php foreach ($questions as $index => $question): ?>
                    <div class="mb-8 p-4 bg-gray-50 border border-gray-200 rounded">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">
                            Pertanyaan <?php echo $index + 1; ?> dari <?php echo count($questions); ?>
                        </h3>
                        <p class="text-gray-700 mb-4"><?php echo htmlspecialchars($question['question_text']); ?></p>

                        <?php if ($question['question_type'] === 'choice'): ?>
                            <?php
                            $options = json_decode($question['options'], true) ?? [];
                            ?>
                            <div class="space-y-2">
                                <?php foreach ($options as $optIdx => $option): ?>
                                    <label class="flex items-center p-2 border border-gray-300 rounded hover:bg-blue-50">
                                        <input type="radio" name="answers[<?php echo $question['id']; ?>]" value="<?php echo $optIdx; ?>" required class="mr-3">
                                        <span class="text-gray-700"><?php echo htmlspecialchars($option); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <textarea name="answers[<?php echo $question['id']; ?>]" required class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" rows="3" placeholder="Jawaban Anda..."></textarea>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <input type="hidden" id="scoreInput" name="score" value="0">

                <div class="flex gap-4">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 font-semibold">
                        Selesaikan Kuis
                    </button>
                    <a href="<?php echo APP_URL; ?>/index.php?page=material_detail&id=<?php echo $id; ?>" class="bg-gray-400 text-white px-6 py-2 rounded hover:bg-gray-500">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('quizForm').addEventListener('submit', function(e) {
            // Calculate simple score (number of answered questions / total questions * 100)
            const form = this;
            const questions = <?php echo count($questions); ?>;
            let answered = 0;
            
            for (let i = 1; i <= questions; i++) {
                const inputs = form.querySelectorAll(`input[name*="[${i}]"], textarea[name*="[${i}]"]`);
                for (let input of inputs) {
                    if (input.value) {
                        answered++;
                        break;
                    }
                }
            }
            
            const score = (answered / questions) * 100;
            document.getElementById('scoreInput').value = score.toFixed(2);
        });
    </script>
</body>
</html>
