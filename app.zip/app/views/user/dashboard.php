<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-blue-600">LMS</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-700">Selamat datang, <strong><?php echo getCurrentUsername(); ?></strong></span>
                    <a href="<?php echo APP_URL; ?>/index.php?action=logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto p-8">
        <?php displayFlash(); ?>

        <h2 class="text-3xl font-bold text-gray-800 mb-8">Dashboard Pembelajaran</h2>

        <?php
        $userModel = new \User();
        $materialModel = new \Material();
        $classId = $_SESSION['class_id'] ?? null;

        if ($classId):
        ?>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <?php
                $slides = $materialModel->getByClassAndType($classId, 'slide');
                $moduls = $materialModel->getByClassAndType($classId, 'modul');
                $lkpds = $materialModel->getByClassAndType($classId, 'lkpd');
                $kuis = $materialModel->getByClassAndType($classId, 'kuis');
                ?>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Slide Materi</p>
                            <p class="text-3xl font-bold text-blue-600"><?php echo count($slides); ?></p>
                        </div>
                        <i class="fas fa-images text-blue-400 text-4xl"></i>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Modul Ajar</p>
                            <p class="text-3xl font-bold text-green-600"><?php echo count($moduls); ?></p>
                        </div>
                        <i class="fas fa-book text-green-400 text-4xl"></i>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">LKPD</p>
                            <p class="text-3xl font-bold text-purple-600"><?php echo count($lkpds); ?></p>
                        </div>
                        <i class="fas fa-file-alt text-purple-400 text-4xl"></i>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600">Kuis</p>
                            <p class="text-3xl font-bold text-red-600"><?php echo count($kuis); ?></p>
                        </div>
                        <i class="fas fa-question-circle text-red-400 text-4xl"></i>
                    </div>
                </div>
            </div>

            <!-- Content Sections -->
            <div class="grid grid-cols-1 gap-8">
                <!-- Slide Materi -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">📊 Slide Materi</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <?php foreach ($slides as $slide): ?>
                            <div class="border rounded-lg p-4 hover:shadow-lg transition">
                                <h4 class="font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($slide['name']); ?></h4>
                                <p class="text-sm text-gray-600 mb-4"><?php echo htmlspecialchars($slide['description'] ?? ''); ?></p>
                                <a href="<?php echo APP_URL; ?>/index.php?page=material_detail&id=<?php echo $slide['id']; ?>" class="text-blue-600 hover:underline">Lihat →</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Modul Ajar -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">📖 Modul Ajar</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <?php foreach ($moduls as $modul): ?>
                            <div class="border rounded-lg p-4 hover:shadow-lg transition">
                                <h4 class="font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($modul['name']); ?></h4>
                                <p class="text-sm text-gray-600 mb-4"><?php echo htmlspecialchars($modul['description'] ?? ''); ?></p>
                                <a href="<?php echo APP_URL; ?>/index.php?page=material_detail&id=<?php echo $modul['id']; ?>" class="text-blue-600 hover:underline">Pelajari →</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- LKPD -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">✏️ LKPD (Lembar Kerja Peserta Didik)</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <?php foreach ($lkpds as $lkpd): ?>
                            <div class="border rounded-lg p-4 hover:shadow-lg transition">
                                <h4 class="font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($lkpd['name']); ?></h4>
                                <p class="text-sm text-gray-600 mb-4"><?php echo htmlspecialchars($lkpd['description'] ?? ''); ?></p>
                                <a href="<?php echo APP_URL; ?>/index.php?page=material_detail&id=<?php echo $lkpd['id']; ?>" class="text-blue-600 hover:underline">Kerjakan →</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Kuis -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">❓ Kuis & Asesmen</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <?php foreach ($kuis as $k): ?>
                            <div class="border rounded-lg p-4 hover:shadow-lg transition">
                                <h4 class="font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($k['name']); ?></h4>
                                <p class="text-sm text-gray-600 mb-4"><?php echo htmlspecialchars($k['description'] ?? ''); ?></p>
                                <a href="<?php echo APP_URL; ?>/index.php?page=quiz&id=<?php echo $k['id']; ?>" class="text-blue-600 hover:underline">Mulai Kuis →</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">
                <p><strong>Perhatian!</strong> Anda belum ditetapkan ke kelas tertentu. Hubungi admin untuk mendapatkan akses.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
