<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Materi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <h1 class="text-2xl font-bold text-blue-600">LMS</h1>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-700">Selamat datang, <strong><?php echo getCurrentUsername(); ?></strong></span>
                    <a href="<?php echo APP_URL; ?>/index.php?action=logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto p-8">
        <a href="<?php echo APP_URL; ?>/index.php?page=dashboard" class="text-blue-600 hover:underline mb-6 inline-block">← Kembali ke Dashboard</a>

        <?php displayFlash(); ?>

        <?php
        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"><p>Materi tidak ditemukan.</p></div>';
            exit;
        }

        $materialModel = new \Material();
        $material = $materialModel->findById($id);

        if (!$material) {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"><p>Materi tidak ditemukan.</p></div>';
            exit;
        }
        ?>

        <div class="bg-white p-8 rounded-lg shadow">
            <div class="mb-6 pb-6 border-b">
                <span class="px-3 py-1 rounded-full text-sm font-semibold bg-blue-100 text-blue-800">
                    <?php echo ucfirst($material['type']); ?>
                </span>
                <h1 class="text-3xl font-bold text-gray-800 mt-2"><?php echo htmlspecialchars($material['name']); ?></h1>
                <p class="text-gray-600 mt-2"><?php echo htmlspecialchars($material['description'] ?? ''); ?></p>
                <p class="text-sm text-gray-500 mt-4">Diunggah pada: <?php echo formatDate($material['created_at']); ?></p>
            </div>

            <!-- Material Content -->
            <div class="mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Konten Materi</h2>
                <div class="bg-gray-50 p-6 rounded-lg border border-gray-200 prose prose-sm max-w-none">
                    <?php echo nl2br(htmlspecialchars($material['content'])); ?>
                </div>
            </div>

            <!-- File Download -->
            <?php if ($material['file_url']): ?>
                <div class="mb-8">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Download File</h2>
                    <a href="<?php echo APP_URL; ?>/public/uploads/<?php echo htmlspecialchars($material['file_url']); ?>" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 inline-block">
                        <i class="fas fa-download mr-2"></i>Download File
                    </a>
                </div>
            <?php endif; ?>

            <!-- Quiz Section -->
            <?php if ($material['type'] === 'kuis'): ?>
                <div class="mb-8 p-6 bg-blue-50 border-l-4 border-blue-500 rounded">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">📝 Kuis Interaktif</h2>
                    <?php
                    $quizModel = new \Quiz();
                    $questions = $quizModel->getQuestions($material['id']);
                    
                    if (isUser()) {
                        $userId = getCurrentUserId();
                        $attempts = $quizModel->getAttemptsCount($userId, $material['id']);
                        $bestScore = $quizModel->getBestScore($userId, $material['id']);
                    }
                    ?>
                    <p class="text-gray-600 mb-4">Jumlah Pertanyaan: <strong><?php echo count($questions); ?></strong></p>
                    
                    <?php if (isUser()): ?>
                        <div class="mb-4">
                            <p class="text-gray-600">Percobaan Anda: <strong><?php echo $attempts; ?>/<?php echo QUIZ_ATTEMPT_LIMIT; ?></strong></p>
                            <?php if ($attempts > 0): ?>
                                <p class="text-gray-600">Skor Terbaik: <strong><?php echo round($bestScore, 2); ?>%</strong></p>
                            <?php endif; ?>
                        </div>

                        <?php if ($quizModel->canAttemptQuiz($userId, $material['id'])): ?>
                            <a href="<?php echo APP_URL; ?>/index.php?page=quiz&id=<?php echo $material['id']; ?>" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 inline-block">
                                <i class="fas fa-play mr-2"></i>Mulai Kuis
                            </a>
                        <?php else: ?>
                            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                                <p>Anda sudah mencapai batas maksimal percobaan untuk kuis ini.</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-gray-600">Login untuk mengikuti kuis ini.</p>
                        <a href="<?php echo APP_URL; ?>/index.php?page=login" class="text-blue-600 hover:underline">Login</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Back Button -->
            <div class="mt-8">
                <a href="<?php echo APP_URL; ?>/index.php?page=dashboard" class="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600">
                    Kembali ke Dashboard
                </a>
            </div>
        </div>
    </div>
</body>
</html>
