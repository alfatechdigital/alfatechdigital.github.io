# API Endpoints Reference

Dokumentasi untuk mengintegrasikan atau extend aplikasi LMS.

## Authentication Endpoints

### Login
```
POST /index.php?action=login
Parameters:
  - username: string (required)
  - password: string (required)
```

### Register
```
POST /index.php?action=register
Parameters:
  - full_name: string (required)
  - email: string (required)
  - username: string (required)
  - password: string (required)
  - password_confirm: string (required)
  - class_id: integer (optional)
```

### Logout
```
GET /index.php?action=logout
```

### Save Diagnostic Assessment
```
POST /index.php?action=save_diagnostic
Parameters:
  - answer_N: string (N = question id)
  - score: float
```

## Admin Endpoints

### Class Management
```
POST /index.php?action=add_class
POST /index.php?action=update_class
POST /index.php?action=delete_class
```

### Material Management
```
POST /index.php?action=add_material
POST /index.php?action=update_material
POST /index.php?action=delete_material
```

### User Management
```
POST /index.php?action=add_user
POST /index.php?action=update_user
POST /index.php?action=delete_user
```

## User Endpoints

### Submit Quiz
```
POST /index.php?action=submit_quiz
Parameters:
  - material_id: integer
  - answers[question_id]: string|integer
  - score: float
```

## Helper Functions

### Authentication
- `isLoggedIn()` - Check if user is logged in
- `isAdmin()` - Check if user is admin
- `isUser()` - Check if user is regular user
- `getCurrentUserId()` - Get current user ID
- `getCurrentUserRole()` - Get current user role
- `redirectIfNotLoggedIn()` - Redirect if not logged in

### Utilities
- `sanitize($input)` - Sanitize input
- `validateEmail($email)` - Validate email
- `setFlash($type, $message)` - Set flash message
- `displayFlash()` - Display flash message
- `formatDate($date)` - Format date
- `hashPassword($password)` - Hash password
- `verifyPassword($password, $hash)` - Verify password

## Models

### User Model
```php
$userModel = new User();

// Methods:
$userModel->findByUsername($username)
$userModel->findByEmail($email)
$userModel->findById($id)
$userModel->create($data)
$userModel->update($id, $data)
$userModel->delete($id)
$userModel->getAllUsers($role)
$userModel->authenticate($username, $password)
$userModel->isDiagnosticCompleted($userId)
```

### ClassModel
```php
$classModel = new ClassModel();

// Methods:
$classModel->findById($id)
$classModel->getAllClasses()
$classModel->create($data)
$classModel->update($id, $data)
$classModel->delete($id)
```

### Material Model
```php
$materialModel = new Material();

// Methods:
$materialModel->findById($id)
$materialModel->getByClassAndType($classId, $type)
$materialModel->create($data)
$materialModel->update($id, $data)
$materialModel->delete($id)
$materialModel->setMaterialAccess($materialId, $classIds)
```

### Quiz Model
```php
$quizModel = new Quiz();

// Methods:
$quizModel->getQuestions($quizId)
$quizModel->addQuestion($data)
$quizModel->saveAttempt($data)
$quizModel->getAttemptsCount($userId, $materialId)
$quizModel->getBestScore($userId, $materialId)
$quizModel->canAttemptQuiz($userId, $materialId)
```

## Database Schema Details

### Users Table
- `id` - Primary key
- `username` - Unique username
- `email` - Unique email
- `password` - Hashed password
- `full_name` - User's full name
- `role` - 'user' or 'admin'
- `class_id` - Foreign key to classes
- `is_active` - Boolean (1 = active, 0 = inactive)
- `diagnostic_completed` - Diagnostic test status (1 = completed)
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

### Classes Table
- `id` - Primary key
- `name` - Class name (unique)
- `description` - Class description
- `created_by` - User ID who created
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

### Materials Table
- `id` - Primary key
- `name` - Material name
- `description` - Material description
- `type` - 'slide', 'modul', 'lkpd', or 'kuis'
- `content` - Material content (HTML/text)
- `file_url` - Uploaded file name
- `class_id` - Foreign key to classes
- `is_published` - Publication status (1 = published, 0 = draft)
- `created_by` - User ID who created
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

### Quiz Questions Table
- `id` - Primary key
- `quiz_id` - Foreign key to materials
- `question_text` - Question text
- `question_type` - 'choice' or 'essay'
- `options` - JSON array of options (for choice type)
- `correct_answer` - Correct answer
- `order_num` - Question order

### Assessment Attempts Table
- `id` - Primary key
- `user_id` - Foreign key to users
- `material_id` - Foreign key to materials
- `answers` - JSON of user answers
- `score` - User score (0-100)
- `attempt_number` - Attempt number
- `completed_at` - Completion timestamp

## Error Codes

| Code | Message | Action |
|------|---------|--------|
| 401 | Unauthorized | Redirect to login |
| 403 | Forbidden | Show access denied page |
| 404 | Not Found | Show 404 page |
| 500 | Server Error | Show error page |

## Best Practices

1. **Always sanitize input** using `sanitize()` function
2. **Validate email** before saving
3. **Hash passwords** using `hashPassword()` function
4. **Check user role** before showing admin features
5. **Use prepared statements** for database queries
6. **Set flash messages** for user feedback
7. **Redirect after POST** to prevent duplicate submissions
8. **Check file uploads** before saving

## Example: Custom Extension

### Adding new Material Type
1. Update `MATERIAL_TYPES` in config
2. Update material type select in forms
3. Add view for the new type
4. Add controller method if needed

### Adding new User Role
1. Update User model
2. Add permission check in views/controllers
3. Update role select in forms
4. Add role-specific views

### Custom Assessment
1. Create new assessment model
2. Add controller methods
3. Create view for assessment
4. Store results in database

---

Last Updated: 2024
