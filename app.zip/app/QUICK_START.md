# LMS Quick Start Guide

## 🚀 Cara Cepat Memulai

### Step 1: Buka Setup
1. Akses: `http://localhost:8000/setup.html`
2. Periksa status semua requirements
3. Database otomatis terbuat

### Step 2: Login ke Aplikasi
1. Kunjungi: `http://localhost:8000/`
2. Login dengan:
   - **Admin**: username `admin`, password `admin123`
   - **User**: username `user`, password `user123`

### Step 3: Kelola Konten (Admin)

#### Tambah Kelas Baru
1. Admin → Manajemen Kelas
2. Klik "Tambah Kelas Baru"
3. Isi nama kelas
4. Klik "Tambah Kelas"

#### Tambah Materi
1. Admin → Manajemen Materi
2. Klik "Tambah Materi Baru"
3. Pilih tipe: Slide Materi, Modul Ajar, LKPD, Kuis
4. Isi konten
5. Publikasikan jika siap
6. Klik "Tambah Materi"

#### Tambah User/Siswa
1. Admin → Manajemen User
2. Klik "Tambah User Baru"
3. Isi data user
4. Assign ke kelas
5. Klik "Tambah User"

### Step 4: User Belajar

1. User login ke sistem
2. Isi asesmen diagnostik (hanya 1x)
3. Dashboard otomatis tampil
4. Akses materi sesuai kelas
5. Mengerjakan kuis (max 3x percobaan)

## 📊 Fitur Utama Dijelaskan

### Dashboard Admin
- Statistik user, kelas, materi
- Quick access ke semua menu
- Ringkasan aktivitas

### Dashboard User
- Card untuk setiap jenis materi
- Akses cepat ke konten pembelajaran
- Progress tracking

### Asesmen Diagnostik
- Pertanyaan essay dan pilihan ganda
- Wajib dipenuhi saat login pertama
- Tidak bisa diulang (stored in database)

### Material Management
- **Slide**: Presentasi/visual learning
- **Modul**: Materi pembelajaran lengkap
- **LKPD**: Lembar kerja interaktif
- **Kuis**: Evaluasi dengan scoring

### Quiz Features
- Pertanyaan pilihan ganda & essay
- Automatic scoring calculations
- 3x attempt limit per student
- Track best score
- Detailed attempt history

## 🔧 Customization

### Ubah Warna/Desain
Edit file-file `.php` di folder `views/`
Gunakan Tailwind CSS classes

### Tambah Field User
1. Edit schema.sql (users table)
2. Migrasi database
3. Update User model
4. Update forms

### Tambah Jenis Materi Baru
1. Update Config.php (MATERIAL_TYPES)
2. Update Material model
3. Update forms
4. Buat view khusus jika perlu

## 📱 Responsive Design

Aplikasi sudah responsive untuk:
- Desktop (1920px+)
- Tablet (768px - 1024px)
- Mobile (320px - 768px)

## 🔐 Security Tips

1. **Change default password** setelah setup
   - Login as Admin
   - Set password baru

2. **Use HTTPS** di production
   - Update APP_URL in Config.php
   - Aktifkan SSL certificate

3. **Backup database** regularly
   - File: `/data/app.db`
   - Gunakan file backup tool

4. **Monitor uploads**
   - Folder: `/public/uploads/`
   - Limit file size
   - Validate file types

## 🆘 Troubleshooting

### Error: Database not found
```
✓ Cek folder /data/ ada
✓ Cek permission folder (755)
✓ Jalankan setup.html
```

### Error: Upload failed
```
✓ Cek folder /public/uploads/ exist
✓ Cek permission folder (755)
✓ Cek file size < 5MB
✓ Cek tipe file allowed
```

### Error: Login failed
```
✓ Buka setup.html untuk reset
✓ Cek database ada
✓ Cek username/password benar
✓ Clear browser cache
```

### Slow loading
```
✓ Check server specs
✓ Enable caching (.htaccess)
✓ Optimize images
✓ Check database size
```

## 📚 Learning Resources

### Access Different Pages
- Home: `/index.php`
- Login: `/index.php?page=login`
- Register: `/index.php?page=register`
- Admin Dashboard: `/index.php?page=admin_dashboard`
- User Dashboard: `/index.php?page=dashboard`

### Database Direct Access (SQLite)
Gunakan SQLite browser untuk:
- View/edit data directly
- Run custom queries
- Backup/restore

### Code Structure
```
Understanding MVC:
- Models: Data layer (User, Material, Quiz)
- Views: UI layer (HTML templates)
- Controllers: Business logic (AuthController, AdminController)
- Config: Settings & database
- Helpers: Utility functions
```

## 🌟 Pro Tips

1. **Bulk Upload Users**
   - Buat user satu per satu sederhana
   - Ekstensikan dengan CSV import

2. **Better Assessment**
   - Edit diagnostic.php untuk pertanyaan custom
   - Tambah rubric dan detailed feedback

3. **Analytics**
   - Query user_assessment_attempts untuk laporan
   - Buat dashboard analytics custom

4. **Add Notifications**
   - Implement email di config
   - Add notification queue

5. **Gamification**
   - Add points system
   - Create leaderboard
   - Add badges

## 📞 Support Resources

1. **README.md** - Dokumentasi lengkap
2. **DOCUMENTATION.md** - API Reference
3. **CHANGELOG.md** - Version history & features
4. **Code comments** - Untuk understanding logic

## ✅ Checklist Implementasi

- [x] Database setup
- [x] User authentication
- [x] Admin panel
- [x] Material management
- [x] Quiz system
- [x] Assessment tracking
- [x] User dashboard
- [x] File uploads
- [x] Responsive design
- [x] Documentation

## 🎯 Next Steps

1. Customize untuk sekolah Anda
2. Tambah logo dan branding
3. Populate sample data
4. Train admin users
5. Deploy ke server
6. Announce ke students
7. Monitor & improve

---

Selamat menggunakan LMS! 🎓

Untuk pertanyaan lebih lanjut, lihat documentation.
