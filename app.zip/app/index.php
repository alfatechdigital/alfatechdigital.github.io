<?php
// Start application
require_once __DIR__ . '/config/Config.php';
require_once __DIR__ . '/config/Helper.php';
require_once __DIR__ . '/config/Database.php';

// Auto-load models
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/models/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Initialize database
$db = new Database();

// Create default admin if not exists
$stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
$stmt->execute();
if ($stmt->fetch(PDO::FETCH_ASSOC)['count'] == 0) {
    $userModel = new User();
    $userModel->create([
        'username' => DEFAULT_ADMIN_USERNAME,
        'email' => DEFAULT_ADMIN_EMAIL,
        'password' => DEFAULT_ADMIN_PASSWORD,
        'full_name' => 'Administrator',
        'role' => 'admin'
    ]);
}

// Create sample data if empty
$classCount = $db->query("SELECT COUNT(*) as count FROM classes")->fetch(PDO::FETCH_ASSOC)['count'];
if ($classCount == 0) {
    $classModel = new ClassModel();
    $classModel->create([
        'name' => 'Kelas X IPA 1',
        'description' => 'Kelas untuk siswa IPA',
        'created_by' => 1
    ]);
    $classModel->create([
        'name' => 'Kelas X IPS 1',
        'description' => 'Kelas untuk siswa IPS',
        'created_by' => 1
    ]);
}

// Create sample user if not exists
$userCount = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user'")->fetch(PDO::FETCH_ASSOC)['count'];
if ($userCount == 0) {
    $userModel = new User();
    $userModel->create([
        'username' => 'user',
        'email' => 'user@example.com',
        'password' => 'user123',
        'full_name' => 'Demo User',
        'role' => 'user',
        'class_id' => 1
    ]);
}

// Route handling
$page = $_GET['page'] ?? 'home';
$action = $_GET['action'] ?? null;

// Handle actions (POST/GET)
if ($action) {
    require_once __DIR__ . '/controllers/AuthController.php';
    require_once __DIR__ . '/controllers/AdminController.php';
    require_once __DIR__ . '/controllers/UserController.php';

    $authController = new AuthController();
    $adminController = new AdminController();
    $userController = new UserController();

    switch ($action) {
        // Auth Actions
        case 'login':
            $authController->login();
            break;
        case 'register':
            $authController->register();
            break;
        case 'logout':
            $authController->logout();
            break;
        case 'save_diagnostic':
            if (isLoggedIn()) {
                $authController->saveDiagnosticAssessment();
            }
            break;

        // Admin Actions
        case 'add_class':
            if (isAdmin()) {
                $adminController->addClass();
            }
            break;
        case 'update_class':
            if (isAdmin()) {
                $adminController->updateClass();
            }
            break;
        case 'delete_class':
            if (isAdmin()) {
                $adminController->deleteClass();
            }
            break;
        case 'add_material':
            if (isAdmin()) {
                $adminController->addMaterial();
            }
            break;
        case 'update_material':
            if (isAdmin()) {
                $adminController->updateMaterial();
            }
            break;
        case 'delete_material':
            if (isAdmin()) {
                $adminController->deleteMaterial();
            }
            break;
        case 'add_user':
            if (isAdmin()) {
                $adminController->addUser();
            }
            break;
        case 'update_user':
            if (isAdmin()) {
                $adminController->updateUser();
            }
            break;
        case 'delete_user':
            if (isAdmin()) {
                $adminController->deleteUser();
            }
            break;
        case 'submit_quiz':
            if (isUser()) {
                $userController->submitQuiz();
            }
            break;
    }
}

// Page routing
if (!file_exists(__DIR__ . '/views/' . str_replace('_', '/', $page) . '.php')) {
    $page = 'home';
}

// Check if requires login
$requireLogin = ['dashboard', 'diagnostic', 'admin_dashboard', 'admin_kelas', 'admin_materi', 'admin_user', 'admin_assessment'];
if (in_array($page, $requireLogin)) {
    redirectIfNotLoggedIn();

    // Check diagnostic assessment for users
    if (strpos($page, 'admin_') !== 0 && $page !== 'diagnostic') {
        if (isUser()) {
            $userModel = new User();
            $user = $userModel->findById(getCurrentUserId());
            if (!$user['diagnostic_completed']) {
                redirect(APP_URL . '/index.php?page=diagnostic');
            }
        }
    }
}

// Check admin pages
$adminPages = ['admin_dashboard', 'admin_kelas', 'admin_materi', 'admin_user', 'admin_assessment'];
if (in_array($page, $adminPages)) {
    redirectIfNotAdmin();
}

// Load view file
require_once __DIR__ . '/views/' . str_replace('_', '/', $page) . '.php';
?>
