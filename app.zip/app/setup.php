<?php
// Quick Setup Script
// Jalankan file ini untuk setup awal

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== LMS Setup Script ===\n\n";

// Check PHP version
if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    die("PHP 7.4+ diperlukan. Versi Anda: " . PHP_VERSION . "\n");
}

echo "[✓] PHP Version: " . PHP_VERSION . "\n";

// Check SQLite
if (!extension_loaded('pdo_sqlite')) {
    die("[✗] PDO SQLite extension tidak tersedia\n");
}

echo "[✓] SQLite Extension: Tersedia\n";

// Create data directory
if (!is_dir(__DIR__ . '/data')) {
    if (mkdir(__DIR__ . '/data', 0755, true)) {
        echo "[✓] Folder data/ berhasil dibuat\n";
    } else {
        die("[✗] Gagal membuat folder data/\n");
    }
} else {
    echo "[✓] Folder data/ sudah ada\n";
}

// Create uploads directory
if (!is_dir(__DIR__ . '/public/uploads')) {
    if (mkdir(__DIR__ . '/public/uploads', 0755, true)) {
        echo "[✓] Folder uploads/ berhasil dibuat\n";
    } else {
        die("[✗] Gagal membuat folder uploads/\n");
    }
} else {
    echo "[✓] Folder uploads/ sudah ada\n";
}

// Try to create database
try {
    $db = new PDO('sqlite:' . __DIR__ . '/data/app.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Check if tables exist
    $tables = $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll();
    
    if (empty($tables)) {
        $sql = file_get_contents(__DIR__ . '/config/schema.sql');
        $db->exec($sql);
        echo "[✓] Database dan table berhasil dibuat\n";
    } else {
        echo "[✓] Database sudah ada dengan " . count($tables) . " table\n";
    }
    
    // Create default admin
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
    $stmt->execute();
    
    if ($stmt->fetch(PDO::FETCH_ASSOC)['count'] == 0) {
        $password = password_hash('admin123', PASSWORD_BCRYPT);
        $stmt = $db->prepare(
            "INSERT INTO users (username, email, password, full_name, role, is_active) 
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute(['admin', 'admin@example.com', $password, 'Administrator', 'admin', 1]);
        echo "[✓] Admin default berhasil dibuat (username: admin, password: admin123)\n";
    } else {
        echo "[✓] Admin sudah ada\n";
    }
    
    // Create sample data
    $classCount = $db->query("SELECT COUNT(*) as count FROM classes")->fetch(PDO::FETCH_ASSOC)['count'];
    if ($classCount == 0) {
        $stmt = $db->prepare(
            "INSERT INTO classes (name, description, created_by) VALUES (?, ?, ?)"
        );
        $stmt->execute(['Kelas X IPA 1', 'Kelas untuk siswa IPA', 1]);
        $stmt->execute(['Kelas X IPS 1', 'Kelas untuk siswa IPS', 1]);
        echo "[✓] Sample kelas berhasil dibuat\n";
    }
    
    // Create sample user
    $userCount = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user'")->fetch(PDO::FETCH_ASSOC)['count'];
    if ($userCount == 0) {
        $password = password_hash('user123', PASSWORD_BCRYPT);
        $stmt = $db->prepare(
            "INSERT INTO users (username, email, password, full_name, role, class_id, is_active) 
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute(['user', 'user@example.com', $password, 'Demo User', 'user', 1, 1]);
        echo "[✓] Sample user berhasil dibuat (username: user, password: user123)\n";
    }
    
    $db = null;
    
} catch (PDOException $e) {
    die("[✗] Database Error: " . $e->getMessage() . "\n");
}

echo "\n=== Setup Selesai! ===\n";
echo "Akses aplikasi di: http://localhost:8000\n";
echo "Kredensial:\n";
echo "  Admin: admin / admin123\n";
echo "  User:  user / user123\n";
?>
