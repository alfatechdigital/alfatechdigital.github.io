<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Assessment.php';

class AuthController {
    private $userModel;
    private $assessmentModel;

    public function __construct() {
        $this->userModel = new User();
        $this->assessmentModel = new Assessment();
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = sanitize($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                setFlash('error', 'Username dan password harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=login');
                exit();
            }

            $user = $this->userModel->authenticate($username, $password);

            if ($user && $user['is_active']) {
                login($user['id'], $user['username'], $user['role'], $user['class_id']);
                setFlash('success', 'Selamat datang, ' . $user['full_name']);

                // Check if diagnostic assessment is required
                if ($user['role'] === 'user' && !$user['diagnostic_completed']) {
                    header('Location: ' . APP_URL . '/index.php?page=diagnostic');
                } elseif ($user['role'] === 'admin') {
                    header('Location: ' . APP_URL . '/index.php?page=admin_dashboard');
                } else {
                    header('Location: ' . APP_URL . '/index.php?page=dashboard');
                }
                exit();
            } else {
                setFlash('error', 'Username atau password salah');
                header('Location: ' . APP_URL . '/index.php?page=login');
                exit();
            }
        }
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = sanitize($_POST['username'] ?? '');
            $email = sanitize($_POST['email'] ?? '');
            $fullName = sanitize($_POST['full_name'] ?? '');
            $password = $_POST['password'] ?? '';
            $passwordConfirm = $_POST['password_confirm'] ?? '';
            $classId = sanitize($_POST['class_id'] ?? '');

            // Validation
            if (empty($username) || empty($email) || empty($fullName) || empty($password)) {
                setFlash('error', 'Semua field harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }

            if (!validateEmail($email)) {
                setFlash('error', 'Format email tidak valid');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }

            if ($password !== $passwordConfirm) {
                setFlash('error', 'Password dan konfirmasi password tidak sesuai');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }

            if (strlen($password) < 6) {
                setFlash('error', 'Password minimal 6 karakter');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }

            // Check if username or email already exists
            if ($this->userModel->findByUsername($username)) {
                setFlash('error', 'Username sudah terdaftar');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }

            if ($this->userModel->findByEmail($email)) {
                setFlash('error', 'Email sudah terdaftar');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }

            $data = [
                'username' => $username,
                'email' => $email,
                'full_name' => $fullName,
                'password' => $password,
                'role' => 'user',
                'class_id' => !empty($classId) ? $classId : null
            ];

            if ($this->userModel->create($data)) {
                setFlash('success', 'Registrasi berhasil! Silakan login');
                header('Location: ' . APP_URL . '/index.php?page=login');
                exit();
            } else {
                setFlash('error', 'Terjadi kesalahan saat registrasi');
                header('Location: ' . APP_URL . '/index.php?page=register');
                exit();
            }
        }
    }

    public function logout() {
        logout();
    }

    public function saveDiagnosticAssessment() {
        if (!isLoggedIn() || !isUser()) {
            header('Location: ' . APP_URL . '/index.php?page=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = getCurrentUserId();
            $answers = [];

            // Collect answers
            foreach ($_POST as $key => $value) {
                if (strpos($key, 'answer_') === 0) {
                    $questionId = str_replace('answer_', '', $key);
                    $answers[$questionId] = sanitize($value);
                }
            }

            $score = isset($_POST['score']) ? (float)$_POST['score'] : 0;

            if ($this->assessmentModel->saveDiagnosticAssessment($userId, $answers, $score)) {
                $this->userModel->markDiagnosticComplete($userId);
                setFlash('success', 'Asesmen diagnostik berhasil disimpan');
                header('Location: ' . APP_URL . '/index.php?page=dashboard');
                exit();
            } else {
                setFlash('error', 'Terjadi kesalahan saat menyimpan asesmen');
                header('Location: ' . APP_URL . '/index.php?page=diagnostic');
                exit();
            }
        }
    }
}
?>
