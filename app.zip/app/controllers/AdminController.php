<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/ClassModel.php';
require_once __DIR__ . '/../models/Material.php';
require_once __DIR__ . '/../models/Quiz.php';
require_once __DIR__ . '/../models/Assessment.php';

class AdminController {
    private $userModel;
    private $classModel;
    private $materialModel;
    private $quizModel;
    private $assessmentModel;

    public function __construct() {
        $this->userModel = new User();
        $this->classModel = new ClassModel();
        $this->materialModel = new Material();
        $this->quizModel = new Quiz();
        $this->assessmentModel = new Assessment();
    }

    // Class Management
    public function addClass() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = sanitize($_POST['name'] ?? '');
            $description = sanitize($_POST['description'] ?? '');

            if (empty($name)) {
                setFlash('error', 'Nama kelas harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
                exit();
            }

            if ($this->classModel->duplicateCheck($name)) {
                setFlash('error', 'Nama kelas sudah ada');
                header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
                exit();
            }

            $data = [
                'name' => $name,
                'description' => $description,
                'created_by' => getCurrentUserId()
            ];

            if ($this->classModel->create($data)) {
                setFlash('success', 'Kelas berhasil ditambahkan');
                header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
                exit();
            }
        }
    }

    public function updateClass() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = sanitize($_POST['id'] ?? '');
            $name = sanitize($_POST['name'] ?? '');
            $description = sanitize($_POST['description'] ?? '');

            if (empty($id) || empty($name)) {
                setFlash('error', 'Semua field harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
                exit();
            }

            if ($this->classModel->duplicateCheck($name, $id)) {
                setFlash('error', 'Nama kelas sudah ada');
                header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
                exit();
            }

            $data = [
                'name' => $name,
                'description' => $description
            ];

            if ($this->classModel->update($id, $data)) {
                setFlash('success', 'Kelas berhasil diperbarui');
            } else {
                setFlash('error', 'Gagal memperbarui kelas');
            }

            header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
            exit();
        }
    }

    public function deleteClass() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = sanitize($_POST['id'] ?? '');

            if (empty($id)) {
                setFlash('error', 'ID kelas tidak valid');
                header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
                exit();
            }

            if ($this->classModel->delete($id)) {
                setFlash('success', 'Kelas berhasil dihapus');
            } else {
                setFlash('error', 'Gagal menghapus kelas');
            }

            header('Location: ' . APP_URL . '/index.php?page=admin_kelas');
            exit();
        }
    }

    // Material Management
    public function addMaterial() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = sanitize($_POST['name'] ?? '');
            $description = sanitize($_POST['description'] ?? '');
            $type = sanitize($_POST['type'] ?? '');
            $content = $_POST['content'] ?? '';
            $classId = sanitize($_POST['class_id'] ?? '');
            $isPublished = isset($_POST['is_published']) ? 1 : 0;

            if (empty($name) || empty($type) || empty($classId)) {
                setFlash('error', 'Nama, tipe, dan kelas harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=admin_materi');
                exit();
            }

            $fileUrl = null;
            if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                $fileUrl = saveUploadedFile($_FILES['file']);
                if (!$fileUrl) {
                    setFlash('error', 'Gagal mengupload file');
                    header('Location: ' . APP_URL . '/index.php?page=admin_materi');
                    exit();
                }
            }

            $data = [
                'name' => $name,
                'description' => $description,
                'type' => $type,
                'content' => $content,
                'file_url' => $fileUrl,
                'class_id' => $classId,
                'is_published' => $isPublished,
                'created_by' => getCurrentUserId()
            ];

            if ($this->materialModel->create($data)) {
                // Set material access for selected classes
                $classIds = $_POST['accessible_classes'] ?? [$classId];
                $lastId = (new Database())->getConnection()->lastInsertId();
                $this->materialModel->setMaterialAccess($lastId, $classIds);

                setFlash('success', 'Materi berhasil ditambahkan');
                header('Location: ' . APP_URL . '/index.php?page=admin_materi');
                exit();
            }
        }
    }

    public function updateMaterial() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = sanitize($_POST['id'] ?? '');
            $name = sanitize($_POST['name'] ?? '');
            $description = sanitize($_POST['description'] ?? '');
            $content = $_POST['content'] ?? '';
            $isPublished = isset($_POST['is_published']) ? 1 : 0;

            if (empty($id) || empty($name)) {
                setFlash('error', 'Semua field harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=admin_materi');
                exit();
            }

            $data = [
                'name' => $name,
                'description' => $description,
                'content' => $content,
                'is_published' => $isPublished
            ];

            if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                $fileUrl = saveUploadedFile($_FILES['file']);
                if ($fileUrl) {
                    $data['file_url'] = $fileUrl;
                }
            }

            if ($this->materialModel->update($id, $data)) {
                setFlash('success', 'Materi berhasil diperbarui');
            } else {
                setFlash('error', 'Gagal memperbarui materi');
            }

            header('Location: ' . APP_URL . '/index.php?page=admin_materi');
            exit();
        }
    }

    public function deleteMaterial() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = sanitize($_POST['id'] ?? '');

            if (empty($id)) {
                setFlash('error', 'ID materi tidak valid');
                header('Location: ' . APP_URL . '/index.php?page=admin_materi');
                exit();
            }

            if ($this->materialModel->delete($id)) {
                setFlash('success', 'Materi berhasil dihapus');
            } else {
                setFlash('error', 'Gagal menghapus materi');
            }

            header('Location: ' . APP_URL . '/index.php?page=admin_materi');
            exit();
        }
    }

    // User Management
    public function addUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = sanitize($_POST['username'] ?? '');
            $email = sanitize($_POST['email'] ?? '');
            $fullName = sanitize($_POST['full_name'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = sanitize($_POST['role'] ?? 'user');
            $classId = sanitize($_POST['class_id'] ?? '');

            if (empty($username) || empty($email) || empty($fullName) || empty($password)) {
                setFlash('error', 'Semua field harus diisi');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }

            if ($this->userModel->findByUsername($username)) {
                setFlash('error', 'Username sudah ada');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }

            if ($this->userModel->findByEmail($email)) {
                setFlash('error', 'Email sudah ada');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }

            $data = [
                'username' => $username,
                'email' => $email,
                'full_name' => $fullName,
                'password' => $password,
                'role' => $role,
                'class_id' => !empty($classId) ? $classId : null
            ];

            if ($this->userModel->create($data)) {
                setFlash('success', 'User berhasil ditambahkan');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }
        }
    }

    public function updateUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = sanitize($_POST['id'] ?? '');
            $fullName = sanitize($_POST['full_name'] ?? '');
            $role = sanitize($_POST['role'] ?? 'user');
            $classId = sanitize($_POST['class_id'] ?? '');

            if (empty($id)) {
                setFlash('error', 'ID user tidak valid');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }

            $data = [
                'full_name' => $fullName,
                'role' => $role,
                'class_id' => !empty($classId) ? $classId : null
            ];

            if ($this->userModel->update($id, $data)) {
                setFlash('success', 'User berhasil diperbarui');
            } else {
                setFlash('error', 'Gagal memperbarui user');
            }

            header('Location: ' . APP_URL . '/index.php?page=admin_user');
            exit();
        }
    }

    public function deleteUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = sanitize($_POST['id'] ?? '');

            if (empty($id)) {
                setFlash('error', 'ID user tidak valid');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }

            // Don't allow deletion of admin account
            $user = $this->userModel->findById($id);
            if ($user && $user['role'] === 'admin') {
                setFlash('error', 'Tidak dapat menghapus akun admin');
                header('Location: ' . APP_URL . '/index.php?page=admin_user');
                exit();
            }

            if ($this->userModel->delete($id)) {
                setFlash('success', 'User berhasil dihapus');
            } else {
                setFlash('error', 'Gagal menghapus user');
            }

            header('Location: ' . APP_URL . '/index.php?page=admin_user');
            exit();
        }
    }
}
?>
