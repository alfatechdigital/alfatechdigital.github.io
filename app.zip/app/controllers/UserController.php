<?php
require_once __DIR__ . '/../models/Material.php';
require_once __DIR__ . '/../models/Quiz.php';
require_once __DIR__ . '/../models/User.php';

class UserController {
    private $materialModel;
    private $quizModel;
    private $userModel;

    public function __construct() {
        $this->materialModel = new Material();
        $this->quizModel = new Quiz();
        $this->userModel = new User();
    }

    public function submitQuiz() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isLoggedIn() && isUser()) {
            $userId = getCurrentUserId();
            $materialId = sanitize($_POST['material_id'] ?? '');
            $answers = $_POST['answers'] ?? [];
            $score = isset($_POST['score']) ? (float)$_POST['score'] : 0;

            if (empty($materialId)) {
                setFlash('error', 'Material tidak valid');
                header('Location: ' . APP_URL . '/index.php?page=dashboard');
                exit();
            }

            // Check if user can attempt quiz
            if (!$this->quizModel->canAttemptQuiz($userId, $materialId)) {
                setFlash('error', 'Anda sudah mencapai batas maksimal percobaan');
                header('Location: ' . APP_URL . '/index.php?page=dashboard');
                exit();
            }

            $data = [
                'user_id' => $userId,
                'material_id' => $materialId,
                'answers' => $answers,
                'score' => $score
            ];

            if ($this->quizModel->saveAttempt($data)) {
                setFlash('success', 'Kuis berhasil disimpan. Skor Anda: ' . round($score, 2) . '%');
                header('Location: ' . APP_URL . '/index.php?page=material_detail&id=' . $materialId);
                exit();
            } else {
                setFlash('error', 'Gagal menyimpan kuis');
                header('Location: ' . APP_URL . '/index.php?page=dashboard');
                exit();
            }
        }
    }

    public function getQuizzes($classId) {
        return $this->materialModel->getByClassAndType($classId, 'kuis');
    }

    public function getModules($classId) {
        return $this->materialModel->getByClassAndType($classId, 'modul');
    }

    public function getLKPD($classId) {
        return $this->materialModel->getByClassAndType($classId, 'lkpd');
    }

    public function getSlides($classId) {
        return $this->materialModel->getByClassAndType($classId, 'slide');
    }

    public function recordProgress($materialId) {
        if (isLoggedIn() && isUser()) {
            $userId = getCurrentUserId();
            // Update to mark as viewed/completed
            // This can be extended with progress tracking table
        }
    }
}
?>
